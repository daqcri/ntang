
MAX_NUM_BITS = 100

def is_submask(sub_mask, super_mask):
    return sub_mask & super_mask == sub_mask

def is_subset(sub_mask, super_mask):
    return sub_mask & super_mask == super_mask

def is_superset(super_mask, sub_mask):
    return is_subset(sub_mask, super_mask)

def get_num_bits(mask):
    for i in range(0, MAX_NUM_BITS):
        if (2 ** i) > mask:
            return i
    raise ArithmeticError('mask is larger than 2^100')

def bit2list(mask):
    num_bits = get_num_bits(mask)
    return [1 if mask & (2 ** i) > 0 else 0 for i in range(num_bits)]

def get_zero_bits(mask, num_bits):
    return [i for i in range(0, num_bits) if mask & (2 ** i) == 0]

def get_one_bits(mask):
    num_bits = get_num_bits(mask)
    return [i for i in range(0, num_bits) if mask & (2 ** i) > 0]

def get_near_sub_masks(mask):
    num_bits = get_num_bits(mask)
    return [mask - 2 ** i for i in range(0, num_bits) if mask & (2 ** i) > 0]

def get_near_super_masks(mask, num_bits):
    return [mask | 2 ** i for i in range(0, num_bits) if mask & (2 ** i) == 0]

def padding(string, length):
    align_space = [' ' for __ in range(0, length - len(string))]
    return string + ''.join(align_space)