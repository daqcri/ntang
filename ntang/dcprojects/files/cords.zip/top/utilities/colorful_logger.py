import inspect
import traceback
import re

COLOR_PURPLE = '\033[95m'
COLOR_BLUE = '\033[96m'
COLOR_GREEN = '\033[92m'
COLOR_YELLOW = '\033[93m'
COLOR_RED = '\033[91m'
COLOR_ENDC = '\033[0m'

color_line_map = {}
color_pointer = 0
def log(*args):
    frame = inspect.currentframe()
    stack_trace = traceback.format_stack(frame)
    stack_parts = stack_trace[-2].split(",")
    full_file = re.search(r"\".*\"", stack_parts[0]).group(0)[1:-1]
    part_file = full_file.split("/")[-1]
    line_num = stack_parts[1].split()[-1]
    method_name = stack_parts[2].split("\n")[0].split(" ")[-1]
    colors = [COLOR_PURPLE, COLOR_BLUE, COLOR_GREEN, COLOR_YELLOW, COLOR_RED, COLOR_ENDC]


    global color_line_map, color_pointer

    if line_num in color_line_map:
        color = color_line_map[line_num]
    else:
        color_pointer = (color_pointer + 1) % len(colors)
        color = colors[color_pointer]
        color_line_map[line_num] = color

    args = map(lambda x: str(x), args)
    message = " ".join(args)
    print color + part_file + "@" + method_name + ":" + line_num, message, COLOR_ENDC
