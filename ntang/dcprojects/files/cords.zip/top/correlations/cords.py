from __future__ import division
__author__ = 'hejian'


SYMBOL_SOFT_KEY = -1
SYMBOL_TRIVIAL = -2
SYMBOL_SOFT_FD = -3
SYMBOL_STRUCTURE_ZERO = 100

PARAM_SINGLE_KEY_CARDINALITY = 0.9
PARAM_COMBINE_MAX_CARDINALITY = 0.5
PARAM_SOFT_FD_RATIO = 0.95
PARAM_MAX_ZERO_RATIO = 0.9
PARAM_FREQUENT_THRESHOLD = 50
PARAM_DATA_SKEW_THRESHOLD = 0.5


TABLE_SAMPLE_SIZE = 100000
MAX_BUCKET_NUM = 1000


from ..utilities.colorful_logger import *
from ..utilities.util import *
import numpy as np
import itertools

global_soft_fds = []

class SoftFD(object):
    """docstring for Node"""
    def __init__(self, lsh_mask, rhs_col):
        self.lsh_mask = lsh_mask
        self.rhs_col = rhs_col

    def __str__(self):
        return "lsh_mask: " + str(self.lsh_mask) + ", rhs_col: " + str(self.rhs_col)

    def __eq__(self, other):
        return self.lsh_mask == other.lsh_mask and self.rhs_col == other.rhs_col

# Main entry
def compute_all_correlations(table, attribute_names):
    table = np.asarray(table)
    num_col = len(table[0])
    num_row = len(table)
    log('num_col', table[0], 'num_row', num_row)

    column_value_count_maps = [{} for col in range(0, num_col)]
    for row in table:
        for col, value in enumerate(row):
            col_map = column_value_count_maps[col]
            col_map[value] = 1 if value not in col_map else col_map[value] + 1

    # Compute key columns
    soft_key_columns = check_soft_key(column_value_count_maps, table)
    non_key_columns = [col for col in range(0, num_col) if col not in soft_key_columns]

    # Compute column data skewness
    # frequent_value_maps: value -> (count, bucket_id)
    frequent_value_maps = [{} for __ in range(0, num_col)]
    is_data_skew = [0 for __ in range(0, num_col)]
    num_buckets = [0 for __ in range(0, num_col)]
    for col in non_key_columns:
        frequent_value_maps[col], is_data_skew[col] = compute_frequent_values(column_value_count_maps[col], len(table))
        num_buckets[col] = len(frequent_value_maps[col]) if is_data_skew[col] else min(MAX_BUCKET_NUM, len(column_value_count_maps[col]))
        log('cardinality', col, ':', len(column_value_count_maps[col]), '\tfreq:', len(frequent_value_maps[col]))

    # Generate samples for column pair computation
    samples = table # np.asarray(random.sample(table, min(num_row, TABLE_SAMPLE_SIZE)))
    print 'key_columns:', [attribute_names[i] for i in soft_key_columns]
    # Compute column correlations
    correlations = {}

    for depth in range(2, 5):
        for combination in itertools.combinations(non_key_columns, depth):
            mask = sum([2 ** i for i in combination])
            correlations[mask] = compute_correlation(mask, samples, frequent_value_maps, is_data_skew, attribute_names, num_buckets)

    return correlations, soft_key_columns

# Column is soft key when cardinality / size > 0.5 which means half of value are unique
def check_soft_key(column_value_count_maps, table):
    soft_key_columns = set()
    for col in range(0, len(table[0])):
        cardinality = len(column_value_count_maps[col])
        if cardinality > PARAM_SINGLE_KEY_CARDINALITY * len(table):
            soft_key_columns.add(col)
        if cardinality == 1:
            soft_key_columns.add(col)
    return soft_key_columns

def compute_frequent_values(column_value_count_map, table_size):
    frequent_value_map = {}
    bucket_id = 0
    frequent_value_ratio = 0.0
    for value, count in column_value_count_map.items():
        if count > PARAM_FREQUENT_THRESHOLD:
            frequent_value_map[value] = (count, bucket_id)
            frequent_value_ratio += count
            bucket_id += 1
    frequent_value_ratio /= table_size
    is_data_skew = frequent_value_ratio > (1 - PARAM_DATA_SKEW_THRESHOLD)
    return frequent_value_map, is_data_skew

# Return a score denote CORRELATION or SOFT FD or SOFT KEY or TRIVIAL COLUMN (column with only one value)
# CORRELATION: score in [0, 1]:
# SOFT FD: score = SYMBOL_SOFT_FD
# SOFT KEY: score = SYMBOL_SOFT_KEY
# TRIVIAL COLUMN: score = score = SYMBOL_TRIVIAL
def compute_correlation(mask, samples, frequent_value_maps, is_data_skew, attribute_names, num_buckets):
    column_ids = get_one_bits(mask)
    combined_column = []
    for row in samples:
        temp_tuple = []
        for c in column_ids:
            temp_tuple.append(row[c])
        combined_column.append(tuple(temp_tuple))

    # Detect SOFT FDs
    global global_soft_fds
    found_fd = False
    for rhs_col in column_ids:
        lhs_mask = mask - (2 ** rhs_col)
        sub_mask = 0
        inner_found_fd = False
        for i in range(2 ** len(get_one_bits(lhs_mask))):
            if SoftFD(sub_mask, rhs_col) in global_soft_fds:
                inner_found_fd = found_fd = True
                break
            sub_mask = (sub_mask - lhs_mask) & lhs_mask

        if inner_found_fd:
            continue

        lhs_tuples = []
        for row in samples:
            lhs_tuple = []
            for c in column_ids:
                if c != rhs_col:
                    lhs_tuple.append(row[c])
            lhs_tuples.append(tuple(lhs_tuple))
        lhs_cardinality = len(set(lhs_tuples))
        combine_cardinality = len(set(combined_column))

        if (combine_cardinality < PARAM_COMBINE_MAX_CARDINALITY * len(samples) and
            lhs_cardinality / combine_cardinality > PARAM_SOFT_FD_RATIO):
            global_soft_fds.append(SoftFD(lhs_mask, rhs_col))
            found_fd = True
    if found_fd:
        return SYMBOL_SOFT_FD

    # Compute sum of each dimension of contingency table
    n = {}
    sum_dimensions = [{} for __ in range(len(column_ids))]
    num_valid_tuples = 0
    for row in samples:
        bucket_tuple = []
        is_valid_tuple = True
        for i, col in enumerate(column_ids):
            if is_data_skew[col] and row[col] not in frequent_value_maps[col]:
                is_valid_tuple = False
                break
            bucket_id = compute_bucket(row[col], num_buckets[col], is_data_skew[col], frequent_value_maps[col])
            bucket_tuple.append(bucket_id)

        if is_valid_tuple:
            # Count on value grid
            bucket_tuple = tuple(bucket_tuple)
            if bucket_tuple in n:
                n[bucket_tuple] += 1
            else:
                n[bucket_tuple] = 0
            num_valid_tuples += 1
            # Compute dimension sum
            for i, bucket_id in enumerate(bucket_tuple):
                sum_dimension = sum_dimensions[i]
                if bucket_id not in sum_dimension:
                    sum_dimension[bucket_id] = 1
                else:
                    sum_dimension[bucket_id] += 1
    num_checks = reduce(lambda x,y : x * y, [len(sum_dimension) for sum_dimension in sum_dimensions])

    ####### Run CORDS, compute correlations ######
    correlation = 0
    for bucket_tuple in n.keys():
        expected_value = 1.0
        for i, bucket_id in enumerate(bucket_tuple):
            expected_value *= sum_dimensions[i][bucket_id] / num_valid_tuples
        observed_value = n[bucket_tuple] / num_valid_tuples
        if expected_value > 0 and n[bucket_tuple] >= 5:
            correlation += (observed_value - expected_value) ** 2 / expected_value

    max_num_buckets = max([num_buckets[col] for col in column_ids])
    correlation = correlation * max_num_buckets / num_checks
    log('mask:', [attribute_names[i] for i in get_one_bits(mask)], 'correlation:', correlation)
    return correlation

def compute_bucket(value, num_value, data_skew, frequent_value_map):
    if data_skew:
        return frequent_value_map[value][1]
    else:
        return hash(value) % num_value

# dict based hash
string_dict = {}
def dict_hash(value):
    global string_dict
    if value in string_dict:
        return string_dict[value]
    else:
        string_dict[value] = len(string_dict) + 1
    return string_dict[value]

def output_correlations_and_keys(correlations, soft_key_columns, table, attribute_names, filename):
    num_col = len(table[0])
    non_key_columns = [col for col in range(0, num_col) if col not in soft_key_columns]
    non_key_mask = sum([2 ** col for col in non_key_columns])
    with open(filename, 'w+') as datafile:
        if soft_key_columns is not None:
            soft_key_names = [attribute_names[i] for i in soft_key_columns]
            datafile.write('key_columns:' + ','.join(soft_key_names)+'\n')

        for soft_fd in global_soft_fds:
            column_ids = get_one_bits(soft_fd.lsh_mask) + [soft_fd.rhs_col]
            correlation_names = ','.join([attribute_names[col] for col in column_ids])
            datafile.write(correlation_names + ':SOFT_FD' + '\n')

        outputs = []
        for mask in range(1, 2 ** num_col):
            if is_submask(mask, non_key_mask) and mask in correlations:
                relation = correlations[mask]
                column_ids = get_one_bits(mask)
                correlation_names = ','.join([attribute_names[col] for col in column_ids])
                if relation != SYMBOL_SOFT_FD and relation != SYMBOL_STRUCTURE_ZERO and relation != SYMBOL_TRIVIAL and relation > 0.01:
                    outputs.append((correlation_names + ':' + '{0:.3f}'.format(relation) + '\n', len(column_ids)))
        outputs = sorted(outputs, key=lambda output: output[1])
        for line in outputs:
            datafile.write(line[0])

