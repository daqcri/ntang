import top.correlations.cords as Cords


def load_table(table_file_name):
    # valid_addr_attributes = ['CUID', 'RUID', 'SSN', 'FNAME', 'MINIT', 'LNAME', 'STNUM', 'STADD', 'APT', 'CITY', 'STATE', 'ZIP']
    # addr_valid_attributes = ['SSN', 'FNAME', 'LNAME', 'STNUM', 'STADD', 'APT', 'CITY', 'STATE', 'ZIP']

    # hospital_valid_attributes = ['ProviderNumber', 'HospitalName', 'Address1',
    #                              'City', 'State', 'ZIPCode', 'CountyName', 'PhoneNumber',
    #                              'HospitalType', 'HospitalOwner', 'EmergencyService', 'Condition',
    #                              'MeasureCode', 'MeasureName', 'Score', 'Sample', 'StateAvg']

    # adult_valid_attributes = ['age', 'workclass', 'fnlwgt', 'education', 'educationnum', 'martialstatus', 'occupation',
    #                           'relationship', 'race', 'sex', 'capitalgain', 'capitalloss',
    #                            'hoursperweek', 'nativecountry', 'agrossincome']
    # adult_valid_attributes = ['age', 'educationnum', 'education']
    # soccer_attributes = ['SoccerPlayer', 'Position','PlayerCountry','SoccerClub','ClubCountry','Stadium','SoccerManager']
    # university_attributes = ['EducationalInstitution', 'Settlement', 'City', 'State', 'areaCode', 'postalCode']
    # crawl_data_attributes = ['ID', 'EVENT_TYPE', 'LHS_LABEL', 'RHS_LABEL', 'LHS', 'RHS_ID', 'LHS_ID', 'RHS', 'DATE', 'ANNOTATION', 'COMMENT']
    valid_attributes = None
    table = []
    with open(table_file_name, 'r') as datafile:
        input_attributes = map(lambda x : x.strip(), datafile.readline().split(","))
        if valid_attributes is None: valid_attributes = input_attributes
        valid_attribute_set = set(valid_attributes)
        for line in datafile:
            row = [value.strip() for col, value in enumerate(line.split(",")) if col < len(input_attributes) and input_attributes[col] in valid_attribute_set]
            table.append(row)
    return table, valid_attributes

def main():
    table_file_name = 'inputDB_clean.csv'
    table, attribute_names = load_table(table_file_name)
    correlations, soft_key_columns = Cords.compute_all_correlations(table, attribute_names)
    correlation_file_name = table_file_name[:-10] + '_cors.csv'
    Cords.output_correlations_and_keys(correlations, soft_key_columns, table, attribute_names, correlation_file_name)

if __name__ == "__main__":
    main()
